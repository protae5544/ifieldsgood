"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Zap, Eye, CheckCircle2 } from "lucide-react"

interface DetectedField {
  id: string
  name: string
  type: "text" | "number" | "date" | "checkbox" | "signature"
  x: number
  y: number
  width: number
  height: number
  page: number
  confidence: number
  required: boolean
}

interface ProcessedDocument {
  id: string
  name: string
  type: string
  status: string
  fields: DetectedField[]
  confidence: number
}

interface FieldDetectorProps {
  documents: ProcessedDocument[]
}

export function FieldDetector({ documents }: FieldDetectorProps) {
  const getFieldTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      text: "bg-blue-100 text-blue-800",
      number: "bg-green-100 text-green-800",
      date: "bg-purple-100 text-purple-800",
      checkbox: "bg-orange-100 text-orange-800",
      signature: "bg-red-100 text-red-800",
    }
    return colors[type] || "bg-gray-100 text-gray-800"
  }

  const getFieldTypeName = (type: string) => {
    const names: Record<string, string> = {
      text: "ข้อความ",
      number: "ตัวเลข",
      date: "วันที่",
      checkbox: "ช่องติ๊ก",
      signature: "ลายเซ็น",
    }
    return names[type] || type
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            การตรวจจับฟิลด์อัตโนมัติ
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {documents.map((doc) => (
              <div key={doc.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-medium">{doc.name}</h3>
                    <p className="text-sm text-muted-foreground">ตรวจพบ {doc.fields.length} ฟิลด์</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <Badge variant="default">เสร็จสิ้น</Badge>
                  </div>
                </div>

                <div className="grid gap-3">
                  {doc.fields.map((field) => (
                    <div key={field.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Badge className={getFieldTypeColor(field.type)}>{getFieldTypeName(field.type)}</Badge>
                        <div>
                          <div className="font-medium text-sm">{field.name}</div>
                          <div className="text-xs text-muted-foreground">
                            หน้า {field.page} • ตำแหน่ง ({field.x}, {field.y}) • ขนาด {field.width}×{field.height}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {field.required && (
                          <Badge variant="destructive" className="text-xs">
                            จำเป็น
                          </Badge>
                        )}
                        <div className="text-sm text-muted-foreground">{Math.round(field.confidence * 100)}%</div>
                      </div>
                    </div>
                  ))}
                </div>

                {doc.fields.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Eye className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>ไม่พบฟิลด์ในเอกสารนี้</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>สรุปการตรวจจับฟิลด์</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {documents.reduce((sum, doc) => sum + doc.fields.filter((f) => f.type === "text").length, 0)}
              </div>
              <div className="text-sm text-muted-foreground">ฟิลด์ข้อความ</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {documents.reduce((sum, doc) => sum + doc.fields.filter((f) => f.type === "number").length, 0)}
              </div>
              <div className="text-sm text-muted-foreground">ฟิลด์ตัวเลข</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {documents.reduce((sum, doc) => sum + doc.fields.filter((f) => f.type === "date").length, 0)}
              </div>
              <div className="text-sm text-muted-foreground">ฟิลด์วันที่</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {documents.reduce((sum, doc) => sum + doc.fields.filter((f) => f.type === "checkbox").length, 0)}
              </div>
              <div className="text-sm text-muted-foreground">ช่องติ๊ก</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">
                {documents.reduce((sum, doc) => sum + doc.fields.filter((f) => f.type === "signature").length, 0)}
              </div>
              <div className="text-sm text-muted-foreground">ลายเซ็น</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
